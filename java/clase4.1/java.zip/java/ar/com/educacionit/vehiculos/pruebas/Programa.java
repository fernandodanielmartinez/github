package ar.com.educacionit.vehiculos.pruebas;

import ar.com.educacionit.vehiculos.entidades.Auto;
import ar.com.educacionit.vehiculos.entidades.Comprador;
import ar.com.educacionit.vehiculos.entidades.Vendedor;

public class Programa {

    public static void main (String args[]) {

//        Vehiculo vehiculo = new Vehiculo(1,2, 3);
//        System.out.println("Alto: "+vehiculo.getAlto()+", Ancho: "+vehiculo.getAncho()+" y Largo: "+vehiculo.getLargo());
//        Persona persona = new Persona ("abc", "def", "ghi");
//        System.out.println("Nombre: "+persona.getNombre()+", Apellido: "+persona.getApellido()+" y Numero de Documento: "+persona.getNumeroDocumento());

        Auto auto = new Auto("Ford", "Focus", "Azul", 1, 1, 2);

        System.out.println("Informacion del auto: "+auto);

        Comprador comprador = new Comprador("Oscar", "Gonzalez", "12345678", 150000);

        System.out.println("Informacion del comprador: "+comprador);

        Vendedor vendedor = new Vendedor("Eduardo", "Gaspar", "87654321", 20);

        System.out.println("Informacion del vendedor: "+vendedor);

    }

}
