package ar.com.educacionit.vehiculos.entidades;

import ar.com.educacionit.base.entidades.Persona;

public class Vendedor extends Persona {

    private int cantAutosVendidos;

    public int getCantAutosVendidos() {
        return cantAutosVendidos;
    }

    public void setCantAutosVendidos(int cantAutosVendidos) {
        this.cantAutosVendidos = cantAutosVendidos;
    }

    public Vendedor ( String nombre, String apellido, String numeroDocumento, int cantAutosVendidos ) {

        super(nombre, apellido, numeroDocumento);
        this.setCantAutosVendidos(cantAutosVendidos);

    }

    public String toString () {

        return String.valueOf(getNombre()+" - "+getApellido()+" - "+getNumeroDocumento()+" - "+getCantAutosVendidos());

    }

}
