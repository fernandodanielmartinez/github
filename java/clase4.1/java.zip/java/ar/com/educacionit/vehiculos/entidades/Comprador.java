package ar.com.educacionit.vehiculos.entidades;

import ar.com.educacionit.base.entidades.Persona;

public class Comprador extends Persona {

    private double presupuesto;

    public Double getPresupuesto() {
        return presupuesto;
    }

    public void setPresupuesto(Double presupuesto) {
        this.presupuesto = presupuesto;
    }

    public Comprador ( String nombre, String apellido, String numeroDocumento, double presupuesto ) {

        super(nombre, apellido, numeroDocumento);
        this.setPresupuesto(presupuesto);

    }

    public String toString () {

        return String.valueOf(getNombre()+" - "+getApellido()+" - "+getNumeroDocumento()+" - "+getPresupuesto());

    }

}
