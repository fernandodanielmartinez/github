public class Cuidador extends Persona {

    private int cantidadDeRaciones;

    public void alimentarAnimales () {

    }

    public int getCantidadDeRaciones() {
        return cantidadDeRaciones;
    }

    public void setCantidadDeRaciones(int cantidadDeRaciones) {
        this.cantidadDeRaciones = cantidadDeRaciones;
    }
}
