public class Zoologico {

    public final int cantidad_animales = 25;
    public final int raciones_por_animal = 5;

    private boolean estado;

    public void abrir () {

    }

    public void alimentarAnimales (int unaCantidadDeRaciones) {

    }

    public void cerrar () {

    }

}
